# 📱 Aria v2 — Guía de instalación paso a paso

## ¿Qué es esto?
Aria es tu compañera de IA personal para Android. Esta guía te lleva de cero a tener la app instalada en tu tablet, aunque nunca hayas usado Android Studio.

---

## PASO 1 — Instalar Android Studio

1. Abrí el navegador en tu PC y entrá a:
   **https://developer.android.com/studio**

2. Hacé clic en el botón verde grande que dice **"Download Android Studio"**

3. Aceptá los términos y descargá el instalador (.exe en Windows)

4. Ejecutá el instalador y seguí los pasos (todo en "Next", no cambies nada)

5. Al final Android Studio se abre solo. Va a descargar componentes extra — esperá que termine (puede tardar 5-10 minutos según tu internet)

6. Cuando te pregunte si querés importar configuración anterior, elegí **"Do not import settings"**

---

## PASO 2 — Abrir el proyecto Aria

1. En la pantalla de bienvenida de Android Studio, hacé clic en:
   **"Open"** (o "Open an Existing Project")

2. Navegá hasta donde descomprimiste el ZIP y seleccioná la carpeta **`aria-v2`**

3. Hacé clic en **OK**

4. Android Studio va a mostrar una barra de progreso abajo que dice "Gradle sync..."
   → Esto puede tardar **3-5 minutos** la primera vez (descarga dependencias)
   → Necesitás internet en este paso

5. Cuando termine, vas a ver el proyecto en el panel izquierdo

---

## PASO 3 — Compilar el APK

1. En el menú superior hacé clic en **Build**

2. Seleccioná **"Build Bundle(s) / APK(s)"**

3. Seleccioná **"Build APK(s)"**

4. Esperá 1-2 minutos. Abajo a la derecha va a aparecer una notificación:
   **"APK(s) generated successfully"**

5. Hacé clic en **"locate"** (en esa notificación) para abrir la carpeta con el APK

6. El archivo se llama: **`app-debug.apk`**

---

## PASO 4 — Instalar en tu tablet

### Opción A: Por correo o Drive (más fácil)
1. Enviate el archivo `app-debug.apk` por correo o subilo a Google Drive
2. En la tablet, abrí el archivo
3. Si te pide permiso para instalar apps externas, tocá "Configuración" y activalo
4. Tocá "Instalar"

### Opción B: Por cable USB
1. Conectá la tablet a la PC con un cable USB
2. En la tablet, abrí **Ajustes → Acerca del dispositivo**
3. Tocá **"Número de compilación"** 7 veces seguidas (esto activa las opciones de desarrollador)
4. Volvé a Ajustes → aparece **"Opciones de desarrollador"**
5. Activá **"Depuración USB"**
6. En Android Studio, hacé clic en el botón ▶ verde (Run)
7. Seleccioná tu tablet de la lista y hacé clic OK
8. La app se instala directo

---

## PASO 5 — Configurar Aria

Al abrir la app por primera vez:

1. Tocá el ícono **⚙** arriba a la derecha
2. Escribí tu nombre
3. El motor **Claude** ya funciona sin clave — Aria se despierta sola
4. Si querés otros motores, necesitás sus claves:
   - **Groq** (gratis): https://console.groq.com → "Create API Key"
   - **Gemini** (gratis): https://aistudio.google.com → "Get API key"
   - **OpenAI** (pago): https://platform.openai.com → "API keys"
5. Tocá **"Guardar · Despertar a Aria"**

---

## ¿Cómo funciona la iniciativa propia?

Aria se activa en segundo plano cada ~2.5 horas y genera un mensaje por sí sola. Si la app está abierta, el mensaje aparece directo en el chat. Si está cerrada, te llega una **notificación** — al tocarla, la app se abre y el mensaje aparece.

Para que funcione necesitás:
- Que la tablet tenga conexión a internet
- Que Aria tenga permiso de notificaciones (te lo pide al abrir por primera vez)

---

## Tabs de la app

| Tab | ¿Para qué? |
|-----|-----------|
| 💬 Chat | Conversación normal con Aria |
| 💻 Código | Generá, explicá y debuggeá código en cualquier lenguaje |
| 🧠 Memoria | Ver, eliminar, exportar e importar la memoria de Aria |

---

## Exportar e importar memoria

Si reinstalás la app o la pasás a otro dispositivo, podés guardar la memoria:

1. Abrí ⚙ → tocá **📤 Exportar**
2. Se descarga un archivo `aria-memoria-FECHA.json`
3. Guardalo en lugar seguro (Drive, correo, etc.)
4. En la nueva instalación, ⚙ → **📥 Importar** → seleccioná el archivo

---

## Solución de problemas

**"Gradle sync failed"**
→ Verificá que tenés internet. Cerrá y volvé a abrir Android Studio.

**La app no instala en la tablet**
→ Ajustes → Seguridad → activá "Instalar aplicaciones de fuentes desconocidas"

**Aria no manda notificaciones**
→ Verificá que la app tiene permiso de notificaciones en Ajustes → Apps → Aria → Notificaciones

**El micrófono no funciona**
→ Ajustes → Apps → Aria → Permisos → activá Micrófono
