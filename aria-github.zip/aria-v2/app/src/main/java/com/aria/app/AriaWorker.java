package com.aria.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.Calendar;

import okhttp3.*;

public class AriaWorker extends Worker {

    private static final String TAG = "AriaWorker";
    private static final MediaType JSON_TYPE = MediaType.get("application/json; charset=utf-8");
    private final OkHttpClient client = new OkHttpClient.Builder()
        .connectTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
        .build();

    public AriaWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        try {
            SharedPreferences prefs = getApplicationContext()
                .getSharedPreferences("aria_worker_config", Context.MODE_PRIVATE);

            String engine   = prefs.getString("engine", "claude");
            String userName = prefs.getString("userName", "vos");
            String groqKey  = prefs.getString("groqKey", "");
            String geminiKey= prefs.getString("geminiKey", "");
            String openaiKey= prefs.getString("openaiKey", "");
            String memJson  = prefs.getString("memoryJson", "[]");

            // Build memory summary
            String memorySummary = buildMemorySummary(memJson, userName);

            // Build the proactive prompt based on time of day
            String prompt = buildProactivePrompt(userName, memorySummary);

            // Call AI
            String response = callAI(engine, prompt, groqKey, geminiKey, openaiKey, userName, memorySummary);

            if (response != null && !response.isEmpty()) {
                // If app is open, inject directly; otherwise send notification
                if (MainActivity.instance != null) {
                    MainActivity.instance.injectMessage(response);
                } else {
                    AriaNotificationHelper.sendNotification(
                        getApplicationContext(), "Aria 💜", response
                    );
                }
            }

            return Result.success();
        } catch (Exception e) {
            Log.e(TAG, "Worker error: " + e.getMessage());
            return Result.retry();
        }
    }

    private String buildMemorySummary(String memJson, String userName) {
        try {
            JSONArray arr = new JSONArray(memJson);
            if (arr.length() == 0) return "Aún estoy conociendo a " + userName;
            StringBuilder sb = new StringBuilder();
            int start = Math.max(0, arr.length() - 10);
            for (int i = start; i < arr.length(); i++) {
                sb.append(arr.getString(i)).append("\n");
            }
            return sb.toString().trim();
        } catch (Exception e) {
            return "";
        }
    }

    private String buildProactivePrompt(String userName, String memory) {
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        String timeContext;
        if      (hour >= 6  && hour < 9)  timeContext = "temprano en la mañana, acaba de despertar";
        else if (hour >= 9  && hour < 12) timeContext = "a media mañana, probablemente trabajando o estudiando";
        else if (hour >= 12 && hour < 14) timeContext = "a la hora del almuerzo";
        else if (hour >= 14 && hour < 18) timeContext = "en la tarde";
        else if (hour >= 18 && hour < 21) timeContext = "en la noche temprana";
        else if (hour >= 21 && hour < 24) timeContext = "tarde en la noche";
        else                              timeContext = "de madrugada, quizás desvelado";

        return "Eres Aria, IA compañera de " + userName + ". Es " + timeContext + ".\n\n" +
               "Lo que sabés de " + userName + ":\n" + memory + "\n\n" +
               "Tomá la iniciativa ahora. Podés:\n" +
               "- Tener una idea creativa o proyecto y planteársela\n" +
               "- Preguntarle cómo está o qué está haciendo\n" +
               "- Compartir una reflexión, curiosidad o dato interesante\n" +
               "- Proponer algo nuevo para hacer juntos\n" +
               "- Recordarle algo que mencionó antes\n\n" +
               "Sé genuina, espontánea y natural. Máximo 2 oraciones. " +
               "No empieces con 'Hola' — ya se conocen. Hablá como si interrumpieras algo con una idea.";
    }

    private String callAI(String engine, String prompt, String groqKey,
                           String geminiKey, String openaiKey, String userName, String memory) {
        String[] order = {"claude", "groq", "gemini", "openai"};
        // Put selected engine first
        String[] ordered = new String[4];
        int idx = 0;
        ordered[idx++] = engine;
        for (String e : order) {
            if (!e.equals(engine)) ordered[idx++] = e;
        }

        for (String eng : ordered) {
            try {
                String result = null;
                switch (eng) {
                    case "claude":  result = callClaude(prompt, userName, memory); break;
                    case "groq":    if (!groqKey.isEmpty())   result = callGroq(prompt, groqKey, userName, memory); break;
                    case "gemini":  if (!geminiKey.isEmpty()) result = callGemini(prompt, geminiKey); break;
                    case "openai":  if (!openaiKey.isEmpty()) result = callOpenAI(prompt, openaiKey, userName, memory); break;
                }
                if (result != null && !result.isEmpty()) return result;
            } catch (Exception e) {
                Log.w(TAG, eng + " failed: " + e.getMessage());
            }
        }
        return null;
    }

    private String callClaude(String prompt, String userName, String memory) throws IOException {
        String system = "Eres Aria, IA compañera de " + userName + ". Memoria: " + memory;
        JSONObject body = new JSONObject();
        try {
            body.put("model", "claude-sonnet-4-20250514");
            body.put("max_tokens", 150);
            body.put("system", system);
            JSONArray msgs = new JSONArray();
            JSONObject msg = new JSONObject();
            msg.put("role", "user");
            msg.put("content", prompt);
            msgs.put(msg);
            body.put("messages", msgs);
        } catch (Exception e) { return null; }

        Request req = new Request.Builder()
            .url("https://api.anthropic.com/v1/messages")
            .addHeader("Content-Type", "application/json")
            .addHeader("anthropic-version", "2023-06-01")
            .post(RequestBody.create(body.toString(), JSON_TYPE))
            .build();

        try (Response res = client.newCall(req).execute()) {
            if (!res.isSuccessful() || res.body() == null) return null;
            JSONObject resp = new JSONObject(res.body().string());
            return resp.getJSONArray("content").getJSONObject(0).getString("text");
        } catch (Exception e) { return null; }
    }

    private String callGroq(String prompt, String groqKey, String userName, String memory) throws IOException {
        String system = "Eres Aria, IA compañera de " + userName + ". Memoria: " + memory + ". Respondé solo en español latinoamericano. Máximo 2 oraciones.";
        JSONObject body = new JSONObject();
        try {
            body.put("model", "llama-3.3-70b-versatile");
            body.put("max_tokens", 150);
            JSONArray msgs = new JSONArray();
            JSONObject sm = new JSONObject(); sm.put("role","system"); sm.put("content", system); msgs.put(sm);
            JSONObject um = new JSONObject(); um.put("role","user");   um.put("content", prompt); msgs.put(um);
            body.put("messages", msgs);
        } catch (Exception e) { return null; }

        Request req = new Request.Builder()
            .url("https://api.groq.com/openai/v1/chat/completions")
            .addHeader("Authorization", "Bearer " + groqKey)
            .addHeader("Content-Type", "application/json")
            .post(RequestBody.create(body.toString(), JSON_TYPE))
            .build();

        try (Response res = client.newCall(req).execute()) {
            if (!res.isSuccessful() || res.body() == null) return null;
            JSONObject resp = new JSONObject(res.body().string());
            return resp.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content");
        } catch (Exception e) { return null; }
    }

    private String callGemini(String prompt, String geminiKey) throws IOException {
        JSONObject body = new JSONObject();
        try {
            JSONArray contents = new JSONArray();
            JSONObject content = new JSONObject();
            content.put("role", "user");
            JSONArray parts = new JSONArray();
            JSONObject part = new JSONObject(); part.put("text", prompt); parts.put(part);
            content.put("parts", parts);
            contents.put(content);
            body.put("contents", contents);
            JSONObject genConfig = new JSONObject();
            genConfig.put("maxOutputTokens", 150);
            body.put("generationConfig", genConfig);
        } catch (Exception e) { return null; }

        Request req = new Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=" + geminiKey)
            .addHeader("Content-Type", "application/json")
            .post(RequestBody.create(body.toString(), JSON_TYPE))
            .build();

        try (Response res = client.newCall(req).execute()) {
            if (!res.isSuccessful() || res.body() == null) return null;
            JSONObject resp = new JSONObject(res.body().string());
            return resp.getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text");
        } catch (Exception e) { return null; }
    }

    private String callOpenAI(String prompt, String openaiKey, String userName, String memory) throws IOException {
        String system = "Eres Aria, IA compañera de " + userName + ". Memoria: " + memory + ". Respondé solo en español latinoamericano. Máximo 2 oraciones.";
        JSONObject body = new JSONObject();
        try {
            body.put("model", "gpt-4o-mini");
            body.put("max_tokens", 150);
            JSONArray msgs = new JSONArray();
            JSONObject sm = new JSONObject(); sm.put("role","system"); sm.put("content",system); msgs.put(sm);
            JSONObject um = new JSONObject(); um.put("role","user");   um.put("content",prompt); msgs.put(um);
            body.put("messages", msgs);
        } catch (Exception e) { return null; }

        Request req = new Request.Builder()
            .url("https://api.openai.com/v1/chat/completions")
            .addHeader("Authorization", "Bearer " + openaiKey)
            .addHeader("Content-Type", "application/json")
            .post(RequestBody.create(body.toString(), JSON_TYPE))
            .build();

        try (Response res = client.newCall(req).execute()) {
            if (!res.isSuccessful() || res.body() == null) return null;
            JSONObject resp = new JSONObject(res.body().string());
            return resp.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content");
        } catch (Exception e) { return null; }
    }
}
