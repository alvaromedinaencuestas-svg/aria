package com.aria.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.*;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.work.*;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private static final int PERM_CODE = 101;
    public static MainActivity instance;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        instance = this;

        // Full screen immersive
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(false);
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            );
        }

        setContentView(R.layout.activity_main);
        webView = findViewById(R.id.webview);

        // WebView settings
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(true);
        ws.setAllowUniversalAccessFromFileURLs(true);
        ws.setAllowFileAccessFromFileURLs(true);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        ws.setUserAgentString("Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36");
        android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setCacheMode(WebSettings.LOAD_DEFAULT);
        ws.setSupportZoom(false);
        ws.setBuiltInZoomControls(false);
        ws.setDisplayZoomControls(false);

        // JS Bridge
        webView.addJavascriptInterface(new AriaJSBridge(this), "AriaApp");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> request.grant(request.getResources()));
            }
            @Override
            public boolean onConsoleMessage(ConsoleMessage msg) {
                // Forward console to logcat for debugging
                android.util.Log.d("AriaWebView", msg.message());
                return true;
            }
        });

        // Request permissions
        requestAllPermissions();

        // Load app
        webView.loadUrl("file:///android_asset/public/index.html");

        // Handle notification tap
        handleNotificationIntent(getIntent());

        // Start background worker
        scheduleAriaWorker();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleNotificationIntent(intent);
    }

    private void handleNotificationIntent(Intent intent) {
        if (intent == null) return;
        String message = intent.getStringExtra("aria_message");
        if (message != null && !message.isEmpty()) {
            // Inject the notification message into the chat
            String safe = message.replace("'", "\\'").replace("\n", "\\n");
            webView.post(() ->
                webView.evaluateJavascript(
                    "if(window.receiveProactiveMessage) receiveProactiveMessage('" + safe + "');",
                    null
                )
            );
        }
    }

    // Called from AriaWorker to inject a message when app is open
    public void injectMessage(String message) {
        if (webView == null) return;
        String safe = message.replace("'", "\\'").replace("\n", "\\n");
        webView.post(() ->
            webView.evaluateJavascript(
                "if(window.receiveProactiveMessage) receiveProactiveMessage('" + safe + "');",
                null
            )
        );
    }

    private void scheduleAriaWorker() {
        // Run every 2.5 hours, starting after 30 min
        PeriodicWorkRequest workRequest = new PeriodicWorkRequest.Builder(
            AriaWorker.class, 150, TimeUnit.MINUTES
        )
        .setInitialDelay(30, TimeUnit.MINUTES)
        .setConstraints(new Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build())
        .build();

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "aria_proactive",
            ExistingPeriodicWorkPolicy.KEEP,
            workRequest
        );
    }

    private void requestAllPermissions() {
        String[] perms = {
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
        };
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms = new String[]{
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.POST_NOTIFICATIONS,
                Manifest.permission.ACCESS_FINE_LOCATION,
            };
        }
        boolean needsRequest = false;
        for (String p : perms) {
            if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) {
                needsRequest = true;
                break;
            }
        }
        if (needsRequest) {
            ActivityCompat.requestPermissions(this, perms, PERM_CODE);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onResume() { super.onResume(); webView.onResume(); }
    @Override
    protected void onPause() { super.onPause(); webView.onPause(); }
    @Override
    protected void onDestroy() { super.onDestroy(); instance = null; }
}
