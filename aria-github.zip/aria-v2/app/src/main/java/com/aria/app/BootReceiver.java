package com.aria.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.work.*;
import java.util.concurrent.TimeUnit;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            PeriodicWorkRequest workRequest = new PeriodicWorkRequest.Builder(
                AriaWorker.class, 150, TimeUnit.MINUTES
            )
            .setConstraints(new Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build())
            .build();

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                "aria_proactive",
                ExistingPeriodicWorkPolicy.KEEP,
                workRequest
            );
        }
    }
}
