package com.aria.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.webkit.JavascriptInterface;
import android.util.Log;

public class AriaJSBridge {

    private final Context context;
    private static final String TAG = "AriaJSBridge";

    public AriaJSBridge(Context context) {
        this.context = context;
    }

    // Save a value to native SharedPreferences (survives app reinstall if backed up)
    @JavascriptInterface
    public void saveNative(String key, String value) {
        try {
            SharedPreferences prefs = context.getSharedPreferences("aria_data", Context.MODE_PRIVATE);
            prefs.edit().putString(key, value).apply();
        } catch (Exception e) {
            Log.e(TAG, "saveNative error: " + e.getMessage());
        }
    }

    // Load a value from native SharedPreferences
    @JavascriptInterface
    public String loadNative(String key) {
        try {
            SharedPreferences prefs = context.getSharedPreferences("aria_data", Context.MODE_PRIVATE);
            return prefs.getString(key, "");
        } catch (Exception e) {
            Log.e(TAG, "loadNative error: " + e.getMessage());
            return "";
        }
    }

    // Get app version
    @JavascriptInterface
    public String getAppVersion() {
        try {
            return context.getPackageManager()
                .getPackageInfo(context.getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "2.0";
        }
    }

    // Send a local notification from JS
    @JavascriptInterface
    public void sendNotification(String title, String message) {
        try {
            AriaNotificationHelper.sendNotification(context, title, message);
        } catch (Exception e) {
            Log.e(TAG, "sendNotification error: " + e.getMessage());
        }
    }

    // Store config so the background worker can access API keys
    @JavascriptInterface
    public void syncConfigForWorker(String engine, String claudeNote,
                                     String groqKey, String geminiKey, String openaiKey,
                                     String userName, String memoryJson) {
        try {
            SharedPreferences prefs = context.getSharedPreferences("aria_worker_config", Context.MODE_PRIVATE);
            prefs.edit()
                .putString("engine", engine)
                .putString("groqKey", groqKey)
                .putString("geminiKey", geminiKey)
                .putString("openaiKey", openaiKey)
                .putString("userName", userName)
                .putString("memoryJson", memoryJson)
                .apply();
        } catch (Exception e) {
            Log.e(TAG, "syncConfigForWorker error: " + e.getMessage());
        }
    }

    // Toast from JS (for debug)
    @JavascriptInterface
    public void showToast(String msg) {
        ((MainActivity) context).runOnUiThread(() ->
            android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_SHORT).show()
        );
    }
}
